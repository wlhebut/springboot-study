create function f_rand_num(start_num bigint, end_num bigint) returns bigint
BEGIN
    RETURN FLOOR(start_num + RAND() * (end_num - start_num + 1));
END;

