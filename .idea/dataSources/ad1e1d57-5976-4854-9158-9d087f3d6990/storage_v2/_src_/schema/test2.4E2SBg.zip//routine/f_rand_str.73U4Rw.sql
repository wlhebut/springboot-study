create function f_rand_str(l int) returns varchar(256)
BEGIN
	DECLARE chars_range varchar(128) DEFAULT 'abcdefghijklmnopqrstuvwxyz';
	DECLARE random_str varchar(256) DEFAULT '';
	DECLARE i INT DEFAULT 0;
	
	WHILE i < l DO
	    SET random_str = concat(random_str, char(ascii('a') + f_rand_num(0, 25)));
	    SET i = i +1;
	END WHILE;
	
	RETURN random_str;
    END;

