create procedure p_make_data(IN l int)
BEGIN
	DECLARE i INT DEFAULT 0;
	
	WHILE i < l DO
	    insert into `t_member` (`member_no`, `user_name`, `register_date`) 
		values(f_rand_num(100000000000, 999999999999), f_rand_str(8), '2016-08-01');
	    SET i = i + 1;
	    
	    IF (i % 1000 = 0) THEN
		select @i;
	    END IF;
	    
	END WHILE;
    END;

